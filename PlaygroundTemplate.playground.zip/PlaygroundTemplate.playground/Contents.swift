//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground

class Scene: SKScene {
    //var and let
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        
    }
    
}

//-----------------------------------------------------------------------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))
skView.showsNodeCount = true
skView.showsFPS = true
let scene = Scene(size: CGSize(width: 300, height: 400))

skView.presentScene(scene)

XCPlaygroundPage.currentPage.liveView = skView
