//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
     let sphereObject : UInt32 = 0x01;
    override init(size: CGSize) {
        super.init(size: size)
        
        physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
       // self.physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        
        //Create a ball shape
        let path = CGPathCreateMutable();
        CGPathAddArc(path, nil, 0, 0, 45, 0, 2, true);
        CGPathCloseSubpath(path);
        
        //createBall
        let shapeNode = SKShapeNode();
        shapeNode.path = path;
        shapeNode.lineWidth = 2.0;
        shapeNode.position = CGPoint(x:self.view!.frame.width/2,y:self.view!.frame.height);

        shapeNode.physicsBody = SKPhysicsBody(circleOfRadius: shapeNode.frame.width/2);
        shapeNode.physicsBody!.dynamic = true;
        shapeNode.physicsBody!.mass = 5;
        shapeNode.physicsBody!.friction = 0.2;
        shapeNode.physicsBody!.restitution = 1;
        shapeNode.physicsBody!.collisionBitMask = sphereObject
        shapeNode.physicsBody!.categoryBitMask = sphereObject;
        shapeNode.physicsBody!.contactTestBitMask = sphereObject;
        
        self.addChild(shapeNode)
        
        
    }
    
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
