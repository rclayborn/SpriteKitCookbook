//: Playground - noun: a place where people can play
import XCPlayground //at top
//---------------------------------------------

import UIKit
import SpriteKit

class Scene: SKScene {
    //Player settings
    let playerSpeed:CGFloat = 200
    //Thumb Sticks
    let movementStick = MovementStick(stickName: "MoveStick")
    let attackStick = MovementStick(stickName: "AttackStick")
    //Layers
    var guiLayer = SKNode()
    //Delta time
    var lastUpdateTimeInterval: NSTimeInterval = 0
    let maximumUpdateDeltaTime: NSTimeInterval = 1.0 / 60.0
    //timer
    var lastAttack: NSTimeInterval = 0
    
    override init(size: CGSize) {
        super.init(size: size)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMoveToView(view: SKView) {
        backgroundColor = SKColor.lightGrayColor()
        let myCamera = SKCameraNode()
        camera = myCamera
        addChild(myCamera)
        camera!.addChild(guiLayer)
        
        movementStick.position = CGPoint(x: -((guiLayer.scene?.size.width)!/3), y: -((guiLayer.scene?.size.height)!/3))
        guiLayer.addChild(movementStick)
        
        attackStick.position = CGPoint(x: ((guiLayer.scene?.size.width)!/3), y: -((guiLayer.scene?.size.height)!/3))
        guiLayer.addChild(attackStick)
        
        //Setup characters
        let player = SKSpriteNode(imageNamed: "YellowAlien")
        player.setScale(0.3)
        player.name = "playerNode"
        addChild(player)
    }
    
    override func update(currentTime: CFTimeInterval) {
        //Calculate delta time
        var deltaTime = currentTime - lastUpdateTimeInterval
        deltaTime = deltaTime > maximumUpdateDeltaTime ? maximumUpdateDeltaTime : deltaTime
        lastUpdateTimeInterval = currentTime
        
        //Stick data
        if !(movementStick.movement == CGPointZero) {
            if let player = childNodeWithName("playerNode") {
                let xMovement = ((movementStick.movement.x * CGFloat(deltaTime)) * playerSpeed)
                let yMovement = ((movementStick.movement.y * CGFloat(deltaTime)) * playerSpeed)
                player.position = CGPoint(x: player.position.x + xMovement, y: player.position.y + yMovement)
            }
        }
        
        if currentTime > (lastAttack + 1.5) && attackStick.movement != CGPointZero  {
            if let player = childNodeWithName("playerNode") {
                let node = SKSpriteNode(color: SKColor.blackColor(), size: CGSize(width: 8, height: 8))
                node.userData = ["directionX":attackStick.movement.x,
                                 "directionY":attackStick.movement.y]
                node.name = "playerProjectile"
                node.position = player.position
                addChild(node)
            }
            lastAttack = currentTime
        }
        
        for child in children {
            if child.name == "playerProjectile" {
                child.position = CGPoint(x: child.position.x + (child.userData!["directionX"] as! CGFloat), y: child.position.y + (child.userData!["directionY"] as! CGFloat))
            }
        }
    }
   
}

//-----------------------------------------------

class MovementStick: SKNode {
    
    var stick = SKSpriteNode()
    let radius:CGFloat
    var movement:CGPoint { get {return CGPoint(x: stick.position.x / radius, y: stick.position.y / radius)}
    }
    
    var zPos:CGFloat = 100
    
    init(stickName: String) {
        let background = SKSpriteNode(imageNamed: "stick_bounds")
        background.zPosition = zPos
        radius = background.size.width/2
        
        super.init()
        self.name = stickName
        self.userInteractionEnabled = true

        stick = SKSpriteNode(imageNamed: "stick_centre")
        stick.zPosition = zPos + 1
        self.addChild(background)
        self.addChild(stick)
        
        let constraint = SKConstraint.distance(SKRange(upperLimit: background.size.width/2), toPoint: CGPointZero)
        stick.constraints = [constraint]
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    //MARK: handle interactions
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            let location = touch.locationInNode(self)
            stick.position = location
        }
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            let location = touch.locationInNode(self)
            stick.position = location
        }
    }
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        stick.position = CGPointZero
    }
}

//playground scene setup--------------------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 800, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
