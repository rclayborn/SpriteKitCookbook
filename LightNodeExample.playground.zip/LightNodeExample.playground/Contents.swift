//: Playground - noun: a place where people can play



import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    let lightSource = SKLightNode()
    var box = SKSpriteNode()
    
    override init(size: CGSize) {
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
    
        let background = SKSpriteNode(imageNamed: "RustyPlate")
        background.size = CGSize(width: self.size.height, height: self.size.height)
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        background.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        background.zPosition = -1
        
        background.lightingBitMask = 1
        background.shadowCastBitMask = 0  //will not leave a shadow at 0.
        background.shadowedBitMask = 1
        
        //This line loads the normal maps for a more realistic look.
        //background.normalTexture = SKTexture(imageNamed: "RustyPlateN")
        
        //another method for bring in teh normal map.
       // background.normalTexture = background.texture?.textureByGeneratingNormalMap()
        
        //another smoother more controled method.
        background.normalTexture = background.texture?.textureByGeneratingNormalMapWithSmoothness(0.2, contrast: 0.2)
        
        
        addChild(background)
        
        lightSource.categoryBitMask = 1
        lightSource.falloff = 0.8
        lightSource.ambientColor = SKColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 0.8)
        lightSource.lightColor = SKColor(red: 0.8, green: 0.8, blue: 0.3, alpha: 0.9)
        lightSource.shadowColor = SKColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.3)
        lightSource.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        addChild(lightSource)
    
       // createBox()
        instructions()
    
}
        func instructions() {
            
            let myX = SKLabelNode(fontNamed: "copperPlate")
            myX.text = "tap to chance position"
            myX.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.85)
            myX.fontSize = 25
            addChild(myX)
            
            let myY = SKLabelNode(fontNamed: "copperPlate")
            myY.text = "of the light source"
            myY.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.8)
            myY.fontSize = 25
            addChild(myY)
    }
    
   /* func createBox() {
        //This takes a little more GPUs
        box = SKSpriteNode(imageNamed: "tile_1", normalMapped: true)
         box.size = CGSize(width: self.size.width/4, height: self.size.height/4)
        box.position = CGPoint(x: 250, y: 250)
        box.zPosition = 1
        box.lightingBitMask = 1
        box.shadowCastBitMask = 1
        box.shadowedBitMask = 1
        addChild(box)
        
    }  */

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        let numberCount: UInt32 = 4 //setting limit
        let randomCount = Int(arc4random_uniform(numberCount)) + 1
        
        switch randomCount {
        case 1:
            lightSource.position = CGPoint(x: self.size.width/4, y: self.size.height)
        case 2:
            lightSource.position = CGPoint(x: self.size.width/6, y: self.size.height/6)
        case 3:
            lightSource.position = CGPoint(x: self.size.width, y: self.size.height/2)
        case 4:
            lightSource.position = CGPoint(x: self.size.width, y: self.size.height/6)
        default:
            lightSource.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        }
    }
    
   /* //move the box to see the shadows it cast.
     override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
             let touchLocation = touch.locationInNode(self)
            
            let touch: UITouch = touches.first!
            
            var position: CGPoint = touch.locationInView(self.view)
            
            position = self.convertPointFromView(position)
     
            if(CGRectContainsPoint(box.frame, touchLocation)){
                box.position = position
            }
        }
    }  */
    
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
