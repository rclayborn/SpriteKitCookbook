//: Playground - noun: a place where people can play

import UIKit

import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        addRopeJointItems(CGPoint(x: self.frame.width / 2, y: self.frame.height / 2), numOfJoints: 5, andScene: self)
    }
    
    func addRopeJointItems(leftStartPosition: CGPoint, numOfJoints countJointElements:Int, andScene game:SKScene ){
        
        let itemJointWidth = 25
        
        let leftAnchor = SKSpriteNode(imageNamed: "chain.png")
        leftAnchor.position = CGPointMake(leftStartPosition.x, leftStartPosition.y)
        leftAnchor.size = CGSizeMake(1, 1);
        leftAnchor.zPosition = 2;
        leftAnchor.physicsBody = SKPhysicsBody(rectangleOfSize: leftAnchor.size)
        leftAnchor.physicsBody?.affectedByGravity = false
        leftAnchor.physicsBody?.mass = 999999999;
        game.addChild(leftAnchor)
        
        for index in 0...countJointElements {
            let item = SKSpriteNode(imageNamed: "chain.png")
            item.name = "ropeitem_" + String(index)
            
            item.position = CGPointMake(leftStartPosition.x + CGFloat((index * itemJointWidth)) + CGFloat(itemJointWidth / 2) , leftStartPosition.y + 60)
            
            item.size = CGSizeMake(CGFloat(itemJointWidth + 5), 5);
            item.zPosition = 2;
            
            item.physicsBody = SKPhysicsBody(rectangleOfSize: item.size)
            item.physicsBody?.categoryBitMask = 0;
            game.addChild(item)
            
            var bodyA = SKPhysicsBody()
            
            if (index == 0)
            {
                bodyA = leftAnchor.physicsBody!;
            }
            else {
                let nameString = "ropeitem_" + String(index - 1)
                
                let node = game.childNodeWithName(nameString) as! SKSpriteNode
                bodyA = node.physicsBody!
            }
            let joint = SKPhysicsJointPin.jointWithBodyA(bodyA, bodyB: item.physicsBody!, anchor: CGPointMake((item.position.x - item.size.width/2) + 5, item.position.y))
            
            game.physicsWorld.addJoint(joint)
        }
        
        let rightAnchor = SKSpriteNode(imageNamed: "chain.png")
        rightAnchor.position = CGPointMake(leftStartPosition.x + CGFloat((countJointElements * itemJointWidth)), CGFloat(leftStartPosition.y + 60))
        rightAnchor.size = CGSizeMake(1, 1);
        rightAnchor.zPosition = 2;
        rightAnchor.physicsBody = SKPhysicsBody(rectangleOfSize: rightAnchor.size)
        rightAnchor.physicsBody?.affectedByGravity = false
        rightAnchor.physicsBody?.mass = 999999999;
        game.addChild(rightAnchor)
        
        
        let nameString = NSString(format: "ropeitem_%d", countJointElements - 1)
        
        let node = game.childNodeWithName(nameString as String)
        
        
        let jointLast = SKPhysicsJointPin.jointWithBodyA(node!.physicsBody!, bodyB: rightAnchor.physicsBody!, anchor: rightAnchor.position)
        
        game.physicsWorld.addJoint(jointLast)
    }
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView