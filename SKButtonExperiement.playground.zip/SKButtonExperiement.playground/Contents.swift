//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top
//---------------------------------------------

class Scene: SKScene {
    //var and let
    let buttonImage1 = SKSpriteNode(imageNamed: "bkbtn_d.png")
    let buttonImage2 = SKSpriteNode(imageNamed: "bkbtn.png")
    
    override init(size: CGSize) {
        super.init(size: size)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        button()
        label()
    }
    
    func label() {
        let myLabel = SKLabelNode(fontNamed: "copperPlate")
        myLabel.text = "Button"
        myLabel.fontSize = 28
        myLabel.zPosition = 1
        myLabel.fontColor = SKColor.whiteColor()
        myLabel.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.49)
        addChild(myLabel)

    }
    
    func button() {
        buttonImage2.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        buttonImage2.zPosition = 0
        self.addChild(buttonImage2)
}
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        buttonImage2.removeFromParent()
        buttonImage1.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        buttonImage2.zPosition = 0
         self.addChild(buttonImage1)
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        buttonImage1.removeFromParent()
        buttonImage2.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        buttonImage2.zPosition = 0

        self.addChild(buttonImage2)
    }
}


//-----------------------------------------------
//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView