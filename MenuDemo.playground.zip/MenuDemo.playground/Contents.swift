
//Lesson 1: Using SpirteKit in playground by Randall Clayborn

//double slashes means developers only comments/notes.
/* means all this commented-out*/

//import frameworks that Apple provided to help us play.

import UIKit//don't need on this playground.
import SpriteKit
import XCPlayground//only for Playground.

//create a view butonly for Playground.
let view = SKView(frame: CGRect(x: 0, y: 0, width: 1024, height: 768))

//get ready to show the view, only for Playground.
XCPlaygroundPage.currentPage.liveView = view

//Show first scene
let scene = SKScene(size: CGSize(width: 1024, height: 768))
scene.scaleMode = .AspectFit
view.presentScene(scene)

scene.backgroundColor = SKColor.darkGrayColor()

 /*key commands to remember: let vs. var
SKView - CGRect(x: W: Width: Height:) -XCPlaygroundPage-ScaleMode.AspectFit - presentScene
*/

/*------------------------------------------*/

//learning about NODES. (Lesson2)

let myNode = SKNode()
myNode.position = CGPoint(x: 150, y: 250)
scene.addChild(myNode)
//This node is empty so let put a color sprite there.

let purpleBox = SKSpriteNode(color: SKColor.purpleColor(), size: CGSize(width: 150, height: 120))
purpleBox.position = CGPointZero
myNode.addChild(purpleBox)

//What other things can we do with this node.
purpleBox.alpha = 1.0
purpleBox.hidden = false

/*New properties: SKNode-addChild-Position- SKSpriteNode
CGSize-SKColor-CGPointZero-Alpha-hidden-true-false*/


/* --------------------------------*/

//Let's get things moving with ACTIONS (Lesson 3)
//these are some actions that you could use.

//
//let appear = SKAction.scaleTo(1.0, duration: 0.5)
//    purpleBox.zRotation = 16.0
//
//let leftWiggle = SKAction.rotateByAngle(8.0, duration: 0.5)
//let rightWiggle = leftWiggle.reversedAction()
//let fullWiggle = SKAction.sequence([leftWiggle, rightWiggle])
//
//let scaleUp = SKAction.scaleBy(2.0, duration: 0.25)
//let scaleDown = scaleUp.reversedAction()
//let fullScale = SKAction.sequence(
//    [scaleUp, scaleDown, scaleUp, scaleDown])
//let group = SKAction.group([fullScale, fullWiggle])
//let groupWait = SKAction.repeatAction(group, count: 10)
//
//let disappear = SKAction.scaleTo(0, duration: 0.7)
//let removeFromParent = SKAction.removeFromParent()
//let actions = [appear, groupWait, disappear, removeFromParent]
//    purpleBox.runAction(SKAction.sequence(actions))



//put actions in a function.
func movePurpleSquare() {
    let secondMove = SKAction.moveToX(350, duration: 2.0)
    purpleBox.runAction(secondMove)
}

//call func to see it run.
movePurpleSquare()

//add something about shape nodes...
//add something about images...

/*--------------------------------------*/

//Text on screen (Lesson 4)
let myLabel = SKLabelNode(fontNamed: "My playground Game")
myLabel.text = "My playground Game"
myLabel.fontColor = SKColor.whiteColor()
myLabel.fontSize = 100
myLabel.zPosition = 1
myLabel.position = CGPoint(x: 350, y: 100)
myNode.addChild(myLabel)

let playLabel = SKLabelNode(fontNamed: "Play")
playLabel.text = "play"
playLabel.fontColor = SKColor.blackColor()
playLabel.fontSize = 50
playLabel.zPosition = 1
playLabel.position = CGPoint(x: 0, y: -10)
purpleBox.addChild(playLabel)
//end of playground lesson going to projects.


/*----------------------------------*/

//add an icon image to your Menu.(Lesson 5)
// make sure you put images in View>Navigator>Show projectNavigator
let hero = SKSpriteNode(imageNamed: "bikeSquare.png")
hero.position = CGPoint(x: 330, y: 300)
hero.size = CGSizeMake(250, 250)
myNode.addChild(hero)


/*---------------------------------*/
//next import it to a project.(Lesson 6)
//End


