//: Playground - noun: a place where people can play

import UIKit

import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    let obstacle = SKSpriteNode()
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        
        let obstacle = SKSpriteNode(imageNamed: "obstacle.png")
        obstacle.position = CGPointMake(self.size.width * 1.0, self.size.height * 0.9)
        obstacle.xScale = 0.2
        obstacle.yScale = 0.2
        obstacle.physicsBody = SKPhysicsBody(circleOfRadius: 40)
        obstacle.physicsBody?.dynamic = true;
        obstacle.physicsBody?.affectedByGravity = true;
        obstacle.physicsBody?.restitution = 0.5;
        obstacle.physicsBody?.allowsRotation = false;
        obstacle.physicsBody?.linearDamping = 0.0;
        obstacle.physicsBody?.friction = 0.0;
        obstacle.physicsBody?.velocity = CGVectorMake(-320, 0)
//        obstacle.physicsBody?.categoryBitMask =       ColliderType.moto.rawValue
//        obstacle.physicsBody?.collisionBitMask = ColliderType.Player.rawValue | ColliderType.TeamCar.rawValue | ColliderType.Peloton.rawValue
       
        
    let wait = SKAction.waitForDuration(3.0)
    let block = SKAction.runBlock {
         self.addChild(obstacle)
        self.spawning()
        }
let sequence = SKAction.sequence([wait, block])
self.runAction(sequence)


        
    }
    
    func spawning() {
        //Add random actions from Right to left.
        let moveIntoTraffic = SKAction.moveTo(CGPointZero, duration: 4)
        let wait = SKAction.waitForDuration(2.0)
        let remove = SKAction.removeFromParent()
        let sequence1 = SKAction.sequence([moveIntoTraffic, wait, remove])
        obstacle.runAction(sequence1)
        
    }
    
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
