//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground

class Scene: SKScene {
    //for topdown Scrolling
    var backgroundRoad = SKSpriteNode(imageNamed: "Road1")
    
    override func didMoveToView(view: SKView) {
    createRoad()
    }
    
    func createRoad() {
        backgroundRoad.zPosition = 100
       
       
         makeTopDownScrollingBg()
    }
    
    func makeTopDownScrollingBg() {
        //not that this one has a time factor.
        let moveBackground = SKAction.moveByX(0, y: -backgroundRoad.size.height, duration: NSTimeInterval(0.01 * backgroundRoad.size.width))
        let resetBackGround = SKAction.moveByX(0, y: backgroundRoad.size.height, duration: 0.0)
        let moveBackgoundForever = SKAction.repeatActionForever(SKAction.sequence([moveBackground, resetBackGround]))
        
        //then run a for loop to make the images line up end to end.
        for var i:CGFloat = 0; i<2 + self.frame.size.height / (backgroundRoad.size.height); ++i {
            let sprite = SKSpriteNode(imageNamed:  "Road1")
         
            sprite.position = CGPointMake(sprite.size.width / 2 - 50, i * sprite.size.height)
            sprite.xScale = 0.85
            sprite.yScale = 1.0
            sprite.runAction(moveBackgoundForever)
            self.addChild(sprite)
        }
    }
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))
skView.showsNodeCount = true
skView.showsFPS = true
let scene = Scene(size: CGSize(width: 300, height: 400))

skView.presentScene(scene)

XCPlaygroundPage.currentPage.liveView = skView
