//: Playground -Getting the camera to follow player.

import UIKit
import SpriteKit
import XCPlayground

class Scene: SKScene {

    //1) create an SKCameraNode
      var cam: SKCameraNode!
      let player = SKSpriteNode(imageNamed: "player.png")
      let sprite = SKSpriteNode(imageNamed: "background.png")
    
    override func didMoveToView(view: SKView) {
        
        cam = SKCameraNode()
        //initialize and assign an instance of SKCameraNode to the cam variable.
         //the scale sets the zoom level of the camera on the given position
        cam.setScale(1.00)
        
        //action to zoom in on Charater.
       let zoomIn = SKAction.scaleTo(0.25, duration: 2.5)
        cam.runAction(zoomIn)
        
        //2) add it to your scene camera property
        self.camera = cam //set the scene's camera to reference cam
        self.addChild(cam) //make the cam a childElement of the scene itself.
        
        //position the camera on the gamescene.
        cam.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        
        createPlayer()
        createBackground()
    }

    func createBackground() {
        sprite.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        sprite.zPosition = -1
        sprite.size.width = self.size.width
        sprite.size.height = self.size.height
        self.addChild(sprite)
    }
    
    func createPlayer() {
        //Setup player and enemy
        player.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.2)
        player.size.width = size.width/8
        player.size.height = size.height/8
        player.anchorPoint = CGPoint(x: 0.5, y: 0.0)//so it center on the character
        self.addChild(player)
        
        let move = SKAction.moveToX(0.85, duration: 3)
        player.runAction(move)
        
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        let moveBack = SKAction.moveToX(0.2, duration: 3)
        player.runAction(moveBack)
    }
    
    override func update(currentTime: CFTimeInterval)
    {
        //3) make the camera follow your player position
        cam.position = player.position
    }
}


let scene = Scene()
scene.scaleMode = .AspectFill

let view = SKView(frame: CGRect(x: 0, y: 0, width: 1920, height: 1080))
view.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = view


