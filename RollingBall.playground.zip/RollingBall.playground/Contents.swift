//:MAde by Randall CLayborn

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    let hero = SKSpriteNode(imageNamed: "Ball.png")
    var groundSpeed = 5 //this is how fast the ball rotates.

    override init(size: CGSize) {
        super.init(size: size)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        moveBall()
    }
    func moveBall() {
        //hero position is before left side and ends after right side of scene
        self.hero.position = CGPointMake(CGRectGetMinX(self.frame) - self.hero.size.width + (self.hero.size.width / 2), self.size.height * 0.35)
        addChild(hero)
        //add action to move ball across the scene.
        let moveBall = SKAction.moveToX(self.size.width * 1.3, duration: 8.5)/* use 8.5 seconds to get across the scene */
        hero.runAction(moveBall)
    }
    
    override func update(currentTime: CFTimeInterval) {
        
        //rotate the hero
        let degreeRotation = CDouble(self.groundSpeed) * M_PI / 180
        self.hero.zRotation -= CGFloat(degreeRotation)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       
    }
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 800, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView

