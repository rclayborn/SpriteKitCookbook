//: Made by Randall Clayborn

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    var charPick = Int()
    var character1 = SKSpriteNode()
    var character2 = SKSpriteNode()
    var character3 = SKSpriteNode()
    var sprite = SKSpriteNode()
    var bg = SKSpriteNode()
    
    var imageName = NSString()
    var characterFilename = NSString() //used for storing a filename to load pages
    var pathFilename2 = NSString()//used for storing a filepath to load pages
    var fileExtensionEye = NSString() //used for storing
    var characterTotal = Int()

    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        backgroundColor = SKColor.darkGrayColor()
        let myLabel = SKLabelNode(fontNamed:"CopperPlate")
        myLabel.text = "Pick a Character!";
        myLabel.fontSize = 45;
        myLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame) - 125)
        self.addChild(myLabel)
        charPicker()
    }
    
    func charPicker() {
        
        character1 = SKSpriteNode(imageNamed: "Character1")
        character1.position = CGPointMake(self.size.width * 0.15, self.size.height * 0.5)
        character1.xScale = 0.2
        character1.yScale = 0.2
        self.addChild(character1)
        
        character2 = SKSpriteNode(imageNamed: "Character2")
        character2.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.5)
        character2.xScale = 0.2
        character2.yScale = 0.2
        self.addChild(character2)
        
        character3 = SKSpriteNode(imageNamed: "Character3")
        character3.position = CGPointMake(self.size.width * 0.8, self.size.height * 0.5)
        character3.xScale = 0.2
        character3.yScale = 0.2
        self.addChild(character3)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        for touch in touches {
            let touchLocation = touch.locationInNode(self)
            if (CGRectContainsPoint(character1.frame, touchLocation)) {
                // do something here like  go to another scene using this charater for game.
                print("Character1")
                self.character1.alpha = 0.0
                character1.xScale = 0.0
                character1.yScale = 0.0
                character2.xScale = 0.0
                character2.yScale = 0.0
                character3.xScale = 0.0
                character3.yScale = 0.0
                
                charPick = 1
                loadCharacter()
            }
            if (CGRectContainsPoint(character2.frame, touchLocation)) {
                // do something here like  go to another scene using this charater for game.
                print("Character2")
                self.character2.alpha = 0.0
                character1.xScale = 0.0
                character1.yScale = 0.0
                character2.xScale = 0.0
                character2.yScale = 0.0
                character3.xScale = 0.0
                character3.yScale = 0.0
                charPick = 2
                loadCharacter()
            }
            if (CGRectContainsPoint(character3.frame, touchLocation)) {
                // do something here like  go to another scene using this charater for game.
                print("Character3")
                self.character3.alpha = 0.0
                character1.xScale = 0.0
                character1.yScale = 0.0
                character2.xScale = 0.0
                character2.yScale = 0.0
                character3.xScale = 0.0
                character3.yScale = 0.0
                charPick = 3
                loadCharacter()
            }
        }
    }
    
    func loadCharacter() {
        
        self.removeFromParent()
        self.removeAllChildren()
        self.removeAllActions()
        
        characterFilename = NSString( format:"Character\(charPick)")
        
        sprite = SKSpriteNode(imageNamed:characterFilename as String)
        sprite.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.5);
        sprite.xScale = 0.3
        sprite.yScale = 0.3
        sprite.zPosition = 1
        self.addChild(sprite)
    }
    
    func ToGameScene() {
        
//        let transition = SKTransition.revealWithDirection(SKTransitionDirection.Down, duration: 1.0)
//        let scene = MainGameScene(size: size)
//        scene.scaleMode = SKSceneScaleMode.AspectFill
//        view?.presentScene(scene, transition: transition)
        
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        print("character\(charPick)")
    }
    
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 600, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
