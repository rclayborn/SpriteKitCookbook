//:collisions in SpiteKit xcode 7.3 swift2.2

//import UIKit
import SpriteKit
import XCPlayground

class Scene: SKScene, SKPhysicsContactDelegate {
    
    struct CategoryBitMask {
        static let Ball: UInt32 = 0b1 << 0
        static let Block: UInt32 = 0b1 << 1
        // The next would be `static let ObjectName: UInt32 = 0b1 << 2` and so on.
    }
    
    override func didMoveToView(view: SKView) {
        self.size = CGSize(width: 1920, height: 1080)
        
        self.physicsWorld.contactDelegate = self
        
        // Set the scene world's gravity to 0.
        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        
        // Create an invisible barrier around the scene to keep the ball inside.
        let sceneBound = SKPhysicsBody(edgeLoopFromRect: self.frame)
        sceneBound.friction = 0
        sceneBound.restitution = 1
        self.physicsBody = sceneBound
        
        // Create a ball to bounce around the scene.
        let ball = SKSpriteNode(color: SKColor.whiteColor(), size: CGSize(width: 50, height: 50))
        ball.physicsBody = SKPhysicsBody(rectangleOfSize: ball.size)
        ball.physicsBody!.allowsRotation = false
        ball.physicsBody!.categoryBitMask = CategoryBitMask.Ball
        ball.physicsBody!.contactTestBitMask = CategoryBitMask.Block
        ball.physicsBody!.friction = 0
        ball.physicsBody!.linearDamping = 0
        ball.physicsBody!.restitution = 1
        ball.physicsBody!.velocity = CGVector(dx: 1000, dy: 1000)
        ball.position = CGPoint(x: 0.5 * self.size.width, y: 0.5 * self.size.height)
        self.addChild(ball)
        
        // Create a template for a block.
        let block = SKSpriteNode(color: SKColor.whiteColor(), size: CGSize(width: 150, height: 50))
        block.name = "Block"
        block.physicsBody = SKPhysicsBody(rectangleOfSize: block.size)
        block.physicsBody!.categoryBitMask = CategoryBitMask.Block
        block.physicsBody!.dynamic = false
        block.physicsBody!.friction = 0
        block.physicsBody!.restitution = 1
        
        // Place copies of the block template in the scene in a grid-like order.
        for y in 1...3 {
            for x in 1...11 {
                let b = block.copy() as! SKSpriteNode
                b.position = CGPoint(x: (b.size.width + 10) * CGFloat(x), y: (b.size.height + 10) * CGFloat(y))
                self.addChild(b)
            }
        }
    }

    func didBeginContact(contact: SKPhysicsContact) {
        // Executed if the ball makes contact with the block.
        if contact.bodyA.categoryBitMask == CategoryBitMask.Ball && contact.bodyB.categoryBitMask == CategoryBitMask.Block {
            let block = contact.bodyB.node as! SKSpriteNode
            
            // Turn the block gray if it hasn't been hit yet.
            if block.name == "Block" {
                block.color = SKColor.darkGrayColor()
                block.name = "HalfBlock"
            }
                
                // Remove the block from the scene if it has already been hit.
            else {
                block.removeFromParent()
            }
        }
    }
}


let scene = Scene()
scene.scaleMode = .AspectFit

let view = SKView(frame: CGRect(x: 0, y: 0, width: 1920, height: 1080))
view.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = view

