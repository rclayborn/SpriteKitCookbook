
import XCPlayground
//------------------------------------
import UIKit
import SpriteKit


class Scene: SKScene {
    //var and let
    var monsterIndex = Int(0)
    var monsters = ["blue", "red", "yellow"]
    var monsterButton = SKSpriteNode()
    
    override init(size: CGSize) {
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        backgroundColor = SKColor.grayColor()
        createButton()
        instructions()
    }
    
    func instructions() {
        let pointLabel = SKLabelNode(fontNamed: "copperPlate")
        pointLabel.text = "Tap to select new charater!"
        pointLabel.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.8)
        pointLabel.fontColor = SKColor.greenColor()
        pointLabel.fontSize = 35
        pointLabel.alpha = 1.0
        pointLabel.zPosition = 12
        addChild(pointLabel)
        
       let scoreFlashAction = SKAction.sequence([ SKAction.scaleTo(1.3, duration: 0.1), SKAction.scaleTo(1.0, duration: 0.1)])
        pointLabel.runAction( SKAction.repeatAction(scoreFlashAction, count: 10))
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        for touch in touches {
            
        let location = touch.locationInNode(self)
            
        if nodeAtPoint(location).name == "Monster" {
            self.incrementIndex()
            self.monsterButton.removeFromParent()
            self.createButton()
            
            }
        }
    }
    
    func getMonster() -> String {
        return monsters[monsterIndex]
    }
    
    func incrementIndex() {
        monsterIndex += 1
        if monsterIndex == monsters.count {
            monsterIndex = 0
        }
    }
    
    func createButton() {
        monsterButton = SKSpriteNode()
        monsterButton.name = "Monster"
        monsterButton.anchorPoint = CGPoint(x: 0.5, y: 0.0)
        monsterButton.position = CGPoint(x: 300, y: 50)
        monsterButton.setScale(0.5)
        monsterButton.zPosition = 3
        
        var monsterAnim = [SKTexture]()
        //three images to use for animating the charater.
        for i in 1..<4 {
            let name = "\(getMonster())\(i)"
            monsterAnim.append(SKTexture(imageNamed: name))
        }
        let animateMonster = SKAction.animateWithTextures(monsterAnim, timePerFrame: 0.2, resize: true, restore: true)
        monsterButton.runAction(SKAction.repeatActionForever(animateMonster))
        self.addChild(monsterButton)
    }
}


//playground scene setup----------------------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 600, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
