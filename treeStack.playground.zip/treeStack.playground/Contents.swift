//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene,  SKPhysicsContactDelegate {
    //var and let
    
    var pieceArray = [SKSpriteNode]()
    var basePosition:CGPoint = CGPointZero
    var frameCount = 0.0
    
    let piece0 = SKSpriteNode(imageNamed: "tree_part.png")
    let piece1 = SKSpriteNode(imageNamed: "tree_part.png")

    
    override init(size: CGSize) {
        super.init(size: size)

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        self.physicsWorld.contactDelegate = self
        
        let sprite = SKSpriteNode(imageNamed: "tree_base.png")
        sprite.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.07)
        sprite.zPosition = 1
        sprite.xScale = 1.0
        sprite.yScale = 1.0
        self.addChild(sprite)
        
        spawnStack()
        
    }
         func spawnStack() {
            
            let spriteArray = [piece0, piece1]
            
            basePosition = CGPoint(x: self.size.width / 2, y: self.size.height * 0.2)
            
            for i in 0 ..< 4 {
                let log = spriteArray[i % 2].copy() as! SKSpriteNode
                
                log.position = CGPoint(x: basePosition.x, y: basePosition.y + CGFloat(i) * log.size.height)
                
                self.addChild(log)
                
                pieceArray.append(log)
            }
        }
    
    func moveStack() {
        let oneFrame:NSTimeInterval = 0.016
        
        self.runAction(SKAction.waitForDuration(oneFrame), completion: {
            let log = self.pieceArray[0]
            
            self.pieceArray.append(log)
            
            self.pieceArray.removeFirst()
            
            log.removeAllChildren()
            
            // Set position
            for i in 0 ..< self.pieceArray.count {
                let chunk = self.pieceArray[i]
                chunk.position = CGPoint(x: self.basePosition.x, y: self.basePosition.y + CGFloat(i) * chunk.size.height)
            }
        })
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
      removeChildrenInArray(pieceArray)
    }
    
    func chopLog() {
        self.moveStack()
    }
    
    func update(delta delta: NSTimeInterval) {
        self.frameCount += delta
        
        if self.frameCount >= 1.0 {
            self.chopLog()
            
            self.frameCount = 0.0
            
        }
    }
    
}


//playground scene setup------------------------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 480, height: 800))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 480, height: 800))
skView.presentScene(scene)
//XCPlaygroundPage.currentPage.liveView = skView



