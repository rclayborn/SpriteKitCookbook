//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    var clouds = [SKSpriteNode]()
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        //start here
        let wait = SKAction.waitForDuration(6)
        let run = SKAction.runBlock {
            self.createClouds()
                   }
        self.runAction(SKAction.sequence([wait, run]))
        self.runAction(SKAction.repeatActionForever(SKAction.sequence([wait, run])))
        
    }
    
    func shuffle(var cloudsArray: [SKSpriteNode]) -> [SKSpriteNode] {
        
        for var i = cloudsArray.count - 1; i > 0; i-- {
            
            let j = Int(arc4random_uniform(UInt32(i - 1)));
            
            swap(&cloudsArray[i], &cloudsArray[j]);
            
        }
        
        return cloudsArray;
    }

        func createClouds() -> [SKSpriteNode] {
            for var i = 0; i < 2; i++ {
                let cloud1 = SKSpriteNode(imageNamed: "Cloud1.png");
                cloud1.name = "1";
                cloud1.position = CGPoint(x: self.size.width * 0.25, y: self.size.height * -0.5)
                self.addChild(cloud1)
                let moveUp = SKAction.moveToY(self.frame.height + 50, duration: 6)
                cloud1.runAction(moveUp)
                
                let cloud2 = SKSpriteNode(imageNamed: "Cloud2");
                cloud2.name = "2";
                cloud2.position = CGPoint(x: self.size.width * 0.4, y: self.size.height * 1.8)
                self.addChild(cloud2)
                let moveDown = SKAction.moveToY(self.frame.height - self.frame.height - 50, duration: 6)
                cloud2.runAction(moveDown)
                
                let cloud3 = SKSpriteNode(imageNamed: "Cloud3");
                cloud3.name = "3";
                cloud3.position = CGPoint(x: self.size.width * 0.6, y: self.size.height - self.size.height)
                self.addChild(cloud3)
                cloud3.runAction(moveUp)
                
                let darkCloud = SKSpriteNode(imageNamed: "DarkCloud");
                darkCloud.name = "DarkCloud";
                darkCloud.position = CGPoint(x: self.size.width * 0.8, y: self.size.height * 1.7)
                self.addChild(darkCloud)
                darkCloud.runAction(moveDown)

                clouds.append(cloud1);
                clouds.append(cloud2);
                clouds.append(cloud3);
                clouds.append(darkCloud);

        }
            clouds = shuffle(clouds);
            return clouds;
    }
    
    func randomizeClouds() {
        
        
    }

}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 480))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 800, height: 480))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView