//: Playground - noun: a place where people can play

import SpriteKit
import XCPlayground //at top



class Scene: SKScene {
    //var and let
     let leftEdge = SKNode()
     let rightEdge = SKNode()
    
     var movingSide = Bool()
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
      
        LeftSideBounds()
        RightSideBounds()
        
        let wait = SKAction.waitForDuration(6.0)
        let run = SKAction.runBlock {
//            self.moveSide()
            self.randomSide()
            
        }
        self.runAction(SKAction.sequence([wait, run]))
        self.runAction(SKAction.repeatActionForever(SKAction.sequence([wait, run])))
    }
    
    func moveSide() {
        
        if movingSide == true {
            movingLeftSide()
        } else {
            movingRightSide()
        }
        
    }
    
    func randomSide() {
        let x = arc4random_uniform(2)
        
        switch x {
        case (0):
            movingSide = false
            print("Right\(x)")
            break
        case 1:
            movingSide = true
            print("Left\(x)")
            break
        default:
            break
        }
        moveSide()
    }
    
    func LeftSideBounds() {
        leftEdge.physicsBody = SKPhysicsBody(edgeFromPoint: CGPointMake(self.size.width * 0.1, self.size.height * 0.0), toPoint: CGPointMake(self.size.width * 0.1, self.size.height + 100))
        leftEdge.position = CGPointZero;
        self.addChild(leftEdge)
    }
    
    func RightSideBounds() {
       
        rightEdge.physicsBody = SKPhysicsBody(edgeFromPoint: CGPointMake(self.size.width * 0.91, self.size.height * 0.0), toPoint: CGPointMake(self.size.width * 0.91, self.size.height + 100))
        rightEdge.position = CGPointZero
        self.addChild(rightEdge)
    }
    
    func movingLeftSide() {
        movingSide = false
        let moveOut = SKAction.moveToX(self.size.width * 0.25, duration: 2.5)
        let moveIn = SKAction.moveToX(self.size.width * 0.0, duration: 2.5)

        let seq = SKAction.sequence([moveOut, moveIn])
        leftEdge.runAction(seq)
    }
    
    func movingRightSide() {
         movingSide = true
        let moveIn = SKAction.moveToX(self.size.width * -0.25, duration: 2.5)
        let moveOut = SKAction.moveToX(self.size.width * 0.0, duration: 2.5)
        let seq = SKAction.sequence([moveIn, moveOut])
        rightEdge.runAction(seq)
    }

}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true
skView.showsPhysics = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView


