//SpriteKit and XCPlayground are required modules
import SpriteKit
import PlaygroundSupport

//==========Get scene size ready=========
//Basic dimensions that we will use more later
let frame = CGRect(x: 0, y: 0, width: 320, height: 256)
let midPoint = CGPoint(x: frame.size.width / 2.0, y: frame.size.height / 2.0)
var scene = SKScene(size: frame.size)

//====Create a scene, add something to it====
//make a background shape and color it
var BGShapeNode = SKShapeNode()
BGShapeNode = SKShapeNode(rectOf: CGSize(width: 600, height: 500))
BGShapeNode.position = CGPoint(x: (scene.size.width) * 0.5, y: (scene.size.height) * 0.5)
scene.addChild(BGShapeNode)
BGShapeNode.fillColor = SKColor.gray
let orangeShapeSize = CGSize(width: 600, height: 500)
BGShapeNode.zPosition = -100
// add lemon Head image.
let lemonHead = SKSpriteNode(imageNamed: "lemonHead1")
lemonHead.position = midPoint
lemonHead.setScale(0.1)
scene.addChild(lemonHead)




//====Set up the view and show the scene===
let view = SKView(frame: frame)
view.presentScene(scene)
PlaygroundPage.current.liveView = view

