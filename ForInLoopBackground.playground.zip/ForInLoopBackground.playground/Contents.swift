//: Playground - noun: a place where people can play

import UIKit

import SpriteKit
import XCPlayground //at top


class Scene: SKScene {
    //var and let
    var backgroundRoad = SKSpriteNode(imageNamed: "Road1")
    
    override init(size: CGSize) {
        super.init(size: size)
        
        // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMoveToView(view: SKView) {
        
        let moveBackground = SKAction.moveByX(0, y: -backgroundRoad.size.height, duration: NSTimeInterval(0.01 * backgroundRoad.size.width))
        let resetBackGround = SKAction.moveByX(0, y: backgroundRoad.size.height, duration: 0.0)
        let moveBackgoundForever = SKAction.repeatActionForever(SKAction.sequence([moveBackground, resetBackGround]))

        
        for x in 0...1  {
          
            let sprite = SKSpriteNode(imageNamed:  "Road1")

            if  x < 2 {  sprite.position = CGPointMake(sprite.size.width / 2 - 50,   sprite.size.height)
            }

            sprite.xScale = 0.85
            sprite.yScale = 2.01
            sprite.runAction(moveBackgoundForever)
            self.addChild(sprite)
        }
    }
    
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
//XCPlaygroundPage.currentPage.liveView = skView

