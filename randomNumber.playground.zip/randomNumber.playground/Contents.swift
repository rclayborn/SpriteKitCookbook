//: Playground - noun: a place where people can play

import UIKit

var str = "Here are some random number generators"

//---------------------------------------------------1
func randomInRange(range: Range<Int>) -> Int {
    let count = UInt32(range.endIndex - range.startIndex)
    return  Int(arc4random_uniform(count)) + range.startIndex
}

for _ in 3...100 {
   randomInRange(3...6)
}

//Now call function
randomInRange(3...90)

//------------------------------------------2
//simplest way is:
 var randomNumber = Int(arc4random_uniform(UInt32(7)+1))

/*the reason you would use the one aboce is because you may want a different call every time you spawn a charater or call a function. */

//------------------------------3

//this one is good for dice because it aways starts at one and only go to 6.
let diceFaceCount: UInt32 = 6 //setting limit
let randomRoll = Int(arc4random_uniform(diceFaceCount)) + 1//+1 is to avoid the a 0 number

randomRoll



