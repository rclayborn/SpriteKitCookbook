// This playground shows touch and
//physicsBody xcode 7.3 Swift 2.2.
//Open Assistant Editor and tap on scene.
//Randall Clayborn 2016

import UIKit
import SpriteKit
import XCPlayground

class Scene: SKScene {
    
    let character = SKShapeNode(fileNamed: "charater.png")
    
    override init(size: CGSize) {
        super.init(size: size)
        
        physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            let location = touch.locationInNode(self)
            
            let sprite = SKSpriteNode(imageNamed:"character")
            
            sprite.xScale = 0.1
            sprite.yScale = 0.1
            sprite.position = location
            sprite.physicsBody = SKPhysicsBody(rectangleOfSize: sprite.size)
            sprite.physicsBody!.allowsRotation = false
            sprite.physicsBody!.friction = 1
            sprite.physicsBody!.linearDamping = 0
            sprite.physicsBody!.restitution = 0.5
            sprite.physicsBody!.velocity = CGVector(dx: 0, dy: 0)

            self.addChild(sprite)
        
        }
    }
}


let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))
skView.showsNodeCount = true
skView.showsFPS = true
let scene = Scene(size: CGSize(width: 300, height: 400))

skView.presentScene(scene)

XCPlaygroundPage.currentPage.liveView = skView
