//: Playground - noun: a place where people can play

import UIKit

import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    var sprite1 = SKSpriteNode(imageNamed: "Sprite1")
     var sprite2 = SKSpriteNode(imageNamed: "Sprite2")
     var sprite3 = SKSpriteNode(imageNamed: "Sprite3")
     var sprite4 = SKSpriteNode(imageNamed: "Sprite4")
     var sprite5 = SKSpriteNode(imageNamed: "Sprite5")
    var gobuttonX = CGFloat(100)
    
    var goFoodSprite = SKSpriteNode()
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        
        let pageNumber = 0
        
        let myArray:Array<String> = ["sprite1", "sprite2", "sprite3", "sprite4", "sprite5"]
        
        for var i in 0..<4 {
            let item = myArray[pageNumber*4 + i]
            let goSprite = SKSpriteNode(imageNamed:"\(item)")
            goSprite.name = item
            goSprite.position = CGPointMake(gobuttonX, 275)
            gobuttonX = gobuttonX + 120
            goSprite.xScale = 0.25
            goSprite.yScale = 0.25
            self.addChild(goSprite)
            
            let moveToLeft = SKAction.moveToX(0.0 - 60, duration: 4)
           
            goSprite.runAction(moveToLeft)
        }
    }
    
    
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
