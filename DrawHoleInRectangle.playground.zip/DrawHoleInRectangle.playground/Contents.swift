//: Playground - noun: a place where people can play

import UIKit

import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
       
        
        let box = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 100, height: 100))
        box.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.5)
        box.fillColor = SKColor.greenColor()
        self.addChild(box)
        
        
        let circle = SKShapeNode(circleOfRadius: 30)
        circle.position = CGPoint(x: box.frame.width * 0.5, y: box.frame.height * 0.5)
        circle.fillColor = .yellowColor()
        circle.blendMode = .Subtract
        box.addChild(circle)
    }
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView