//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

enum Direction:Int {
    case right, left, none
}

class Scene: SKScene {
    //var and let
     var touchBoxL = SKSpriteNode()
     var touchBoxR = SKSpriteNode()
     var biker = SKSpriteNode()
    var currentSpeed:CGFloat = 8
    var currentDirection: Direction = .none
    var handleBar = SKSpriteNode()
    
//    override init(size: CGSize) {
//        super.init(size: size)
//    }
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }

    override func didMoveToView(view: SKView) {
     backgroundColor = SKColor.darkGrayColor()
        createPlayer()
        createHandleBar()
    }
    
    func createHandleBar() {
        touchBoxR = SKSpriteNode(imageNamed: "Transparent.png")
        touchBoxR.position = CGPoint(x: self.size.width * 0.2, y: self.size.height * 0.3)
        touchBoxR.zPosition = 1
        touchBoxR.xScale = 0.5
        touchBoxR.yScale = 0.5
        self.addChild(touchBoxR)
        
        touchBoxL = SKSpriteNode(imageNamed: "Transparent.png")
        touchBoxL.position = CGPoint(x: self.size.width * 0.8, y: self.size.height * 0.3)
        touchBoxL.zPosition = 1
        touchBoxL.xScale = 0.5
        touchBoxL.yScale = 0.5
        self.addChild(touchBoxL)

        
        handleBar = SKSpriteNode(imageNamed: "handleRoad.png")
        handleBar.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.2)
        handleBar.zPosition = 1
        handleBar.xScale = 0.5
        handleBar.yScale = 0.5
        self.addChild(handleBar)
    }
    
    func createPlayer() {
        biker = SKSpriteNode(imageNamed: "biker.png")
        biker.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        biker.zPosition = 1
        biker.xScale = 1.0
        biker.yScale = 1.0
        self.addChild(biker)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            let touchLocation = touch.locationInNode(self)
            
            if (CGRectContainsPoint(touchBoxR.frame, touchLocation)) {
                (currentDirection) = .right
            }
            if (CGRectContainsPoint(touchBoxL.frame, touchLocation)) {
                (currentDirection) = .left
            }
        }
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        handleBar.zRotation = CGFloat(0)
         biker.zRotation = CGFloat(0)
        (currentDirection) = .none
        
    }
    
    override func update(currentTime: NSTimeInterval) {
        if (currentDirection) == .left {
            steerLeft()
        biker.position = CGPointMake(biker.position.x + currentSpeed, biker.position.y)
        }
        if (currentDirection) == .right {
            steerRight()
             biker.position = CGPointMake(biker.position.x - currentSpeed, biker.position.y)
        }
    }
    
    //adding turn rotation to bike and handlbar.
    func steerLeft() {
        handleBar.zRotation = CGFloat(-0.2)
        biker.zRotation = CGFloat(-M_PI)/32
    }
    
    func steerRight() {
        handleBar.zRotation = CGFloat(0.2)
        biker.zRotation = CGFloat(M_PI)/32
    }

}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 300, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
