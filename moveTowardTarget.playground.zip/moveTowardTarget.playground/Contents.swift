//: Zombie should follow hero.
import XCPlayground
//--------------------------------------------

import UIKit
import SpriteKit

class Scene: SKScene {
    let zom = SKSpriteNode(imageNamed: "zombie.png")
    let hero = SKSpriteNode()
    let zombieSpeed: CGFloat = 1.0
    var heroHasMoved = false
    var myLabel = SKLabelNode()
    
    override func didMoveToView(view:
        SKView) {
        backgroundColor = SKColor.grayColor()
        heroHasMoved = true
        createZombie()
        createHero()
        instructionLabel()
    }
    
    func instructionLabel() {
        myLabel = SKLabelNode(fontNamed: "copperPlate")
        myLabel.text = "Touch to chase hero"
        myLabel.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.7)
        myLabel.fontSize = 40
        myLabel.fontColor = SKColor.blackColor()
        myLabel.alpha = 1.0
        myLabel.zPosition = 12
        addChild(myLabel)
        
      let scoreFlashAction = SKAction.sequence([ SKAction.scaleTo(1.3, duration: 0.1), SKAction.scaleTo(1.0, duration: 0.1)])
        myLabel.runAction( SKAction.repeatAction(scoreFlashAction, count: 20))
    }
    
    func createZombie() {
        zom.position = CGPoint(x: self.size.width * 0.2, y: self.size.height * 0.35)
        zom.zPosition = 1
        zom.size.width = self.size.width/6
        zom.size.height = self.size.height/6
        
        //need a physicsBody.
        let bodySize = CGSize(width: 50, height: 50)
        zom.physicsBody = SKPhysicsBody(rectangleOfSize:bodySize)
        zom.physicsBody?.dynamic = true
        zom.physicsBody?.affectedByGravity = false
        zom.physicsBody?.allowsRotation = false
        self.addChild(zom)
    }
    
    func createHero() {
        let hero = SKSpriteNode(imageNamed: "player.png")
        hero.position = CGPoint(x: self.size.width * 0.7, y: self.size.height * 0.35)
        hero.size.width = self.size.width/8
        hero.size.height = self.size.height/8
        
        let bodySize = CGSize(width: 50, height: 50)
        hero.physicsBody = SKPhysicsBody(rectangleOfSize:bodySize)
        hero.physicsBody?.dynamic = true
        hero.physicsBody?.affectedByGravity = false
        hero.physicsBody?.allowsRotation = false
        self.addChild(hero)
    }
    
    func moveToHero() {
        if hero.position.x < zom.position.x  {
            zom.position.x -= zombieSpeed
            zom.physicsBody?.applyImpulse(CGVectorMake(4, 0))
        }
        if hero.position.y < zom.position.y  {
            zom.position.y -= zombieSpeed
            zom.physicsBody?.applyImpulse(CGVectorMake(4, 0))
        }
    }
   
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if heroHasMoved == true {
         moveToHero()
        }
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        heroHasMoved = false
    }
    
}

//--------------------------------------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 480, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true
skView.showsPhysics = true

let scene = Scene(size: CGSize(width: 480, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
