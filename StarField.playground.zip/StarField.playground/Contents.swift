//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class StarField: SKNode {
    
    private let baseAlpha: CGFloat = 0.1
    private let baseDuration: CGFloat = 0.5
    private let defaultDelay: NSTimeInterval = 0.03
    private let starSize = CGSizeMake(15.0, 5.0)
    
    internal func beginSpawningStars() {
        let update = SKAction.runBlock {
            [unowned self] in
            self.spawnStar()
        }
        let delay = SKAction.waitForDuration(defaultDelay)
        let updateSequence = SKAction.sequence([delay, update])
        let repeatForever = SKAction.repeatActionForever(updateSequence)
        self.runAction(repeatForever)
    }
    
    private func spawnStar() {
        if let gameScene = self.scene {
            
            let randomPositionY = CGFloat(arc4random_uniform( UInt32(gameScene.size.height)))
            let maxPositionX = CGRectGetMaxX(gameScene.frame)
            let spawnPoint = CGPointMake(maxPositionX, randomPositionY)
            
            let starNode = SKSpriteNode(imageNamed: "Bee")
            starNode.position = spawnPoint
            starNode.size = starSize
            starNode.alpha = baseAlpha + CGFloat(Double(arc4random_uniform(10)) / 10.0)
            self.addChild(starNode)
            
            let destinationX = 0 - CGRectGetWidth(gameScene.frame) - starSize.width
            let duration = NSTimeInterval(baseDuration + CGFloat(Double(arc4random_uniform(10)) / 10.0))
            
            let travel = SKAction.moveByX(destinationX, y:0.0, duration: duration)
            let remove = SKAction.removeFromParent()
            let sequence = SKAction.sequence([travel, remove])
            
            starNode.runAction(sequence)
            
        }
    }
    
}


class Scene: SKScene {
    //var and let
     let starField = StarField()
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

   
    
    override func didMoveToView(view: SKView) {
        self.backgroundColor = SKColor.blackColor()
        self.loadStarField()
    }
    
    func loadStarField() {
        self.addChild(starField)
        starField.beginSpawningStars()
    }
    
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 400, height: 300))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 400, height: 300))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView

