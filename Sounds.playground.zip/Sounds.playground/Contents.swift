//: Playground - Sounds Swift 2.2 xcode 7.3

import UIKit
import SpriteKit
import AVFoundation
import XCPlayground

//DOES NOT REPEAT
class Scene: SKScene {
    override func didMoveToView(view: SKView) {
 //Load "mysoundname.wav"
if let soundURL = NSBundle.mainBundle().URLForResource("hip-guitar", withExtension: "wav") {
    var mySound: SystemSoundID = 0
    AudioServicesCreateSystemSoundID(soundURL, &mySound)
    //Play
AudioServicesPlaySystemSound(mySound);
        }
    }
}


//----------------------as an extension

/*
import AudioToolbox

extension SystemSoundID {
    static func playFileNamed(fileName: String, withExtenstion fileExtension: String? = "wav") {
        var sound: SystemSoundID = 0
        if let soundURL = NSBundle.mainBundle().URLForResource(fileName, withExtension: fileExtension) {
            AudioServicesCreateSystemSoundID(soundURL, &sound)
            AudioServicesPlaySystemSound(sound)
        }
    }
}

class Scene: SKScene {
  override func didMoveToView(view: SKView) {
SystemSoundID.playFileNamed("hip-guitar")
 //or
 //SystemSoundID.playFileNamed("hip-guitar", withExtenstion: "wav")
    }
}
*/

//----------------------inside of class
/*
//Plays longer sounds.
class Scene: SKScene {
    
    var mySound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("hip-guitar", ofType: "wav")!)
    
    var audioPlayer = AVAudioPlayer()
    
    // Initial setup
    override func didMoveToView(view: SKView) {
        //new error handling Swift 2.2
        do {
            audioPlayer = try AVAudioPlayer(contentsOfURL: mySound)
        } catch {
            print("No sound found by URL:\(mySound)")
        }
    audioPlayer.prepareToPlay()
    audioPlayer.play()
        
    }
}
*/

//-------------------------
//playground setup.Place at bottom.
let scene = Scene()
scene.scaleMode = .AspectFill

let view = SKView(frame: CGRect(x: 0, y: 0, width: 1920, height: 1080))
view.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = view




