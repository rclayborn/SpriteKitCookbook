//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    
    override init(size: CGSize) {
        super.init(size: size)
        
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        //setting background to black so it would look like the road.
        backgroundColor = SKColor.blackColor()
        
        createLeftRoadWithPhysics()
        createRightRoadWithPhysics()
        hero() // this is so you will not have to wait 2 second for the first hero.
        
        //this calls the hero every 2 seconds.
        let wait = SKAction.waitForDuration(2)
        let remove = SKAction.removeFromParent()
        let run = SKAction.runBlock {
            self.hero()//method to be repaeted goes in here.
        }
        self.runAction(SKAction.sequence([wait, run]))
        self.runAction(SKAction.repeatActionForever(SKAction.sequence([wait, run, remove])))
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* touch scene to see the location in case you want to make your own path by hand */
        
        for touch in touches {
            let location = touch.locationInNode(self)
            print("\(location)")
        }
    }
    
    func hero() {
        //calling hero as normal scaling his down a bit.
        let hero = SKSpriteNode(imageNamed: "RedMonster.png")
        hero.position = CGPoint(x: self.size.width * 0.35, y: self.size.height * 1.3)
        hero.zPosition = 1
        hero.xScale = 0.4
        hero.yScale = 0.4
        self.addChild(hero)
        hero.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        hero.physicsBody?.affectedByGravity = true
    }
    
    func createLeftRoadWithPhysics() {
        //calling left side of road Grass and positing it.
        let sprite = SKSpriteNode(imageNamed: "grassLeft.png")
        sprite.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        self.addChild(sprite)
        //----------------------------------------------------------
        //Got from: http://mortenjust.com/path-generator/ //easier then figuring it out by hand.
        
        let offsetX = sprite.size.width * sprite.anchorPoint.x
        let offsetY = sprite.size.height * sprite.anchorPoint.y
        
        let path = CGPathCreateMutable()
        
        CGPathMoveToPoint(path, nil, 1 - offsetX, 798 - offsetY)
        CGPathAddLineToPoint(path, nil, 83 - offsetX, 798 - offsetY)
        CGPathAddLineToPoint(path, nil, 122 - offsetX, 724 - offsetY)
        CGPathAddLineToPoint(path, nil, 158 - offsetX, 639 - offsetY)
        CGPathAddLineToPoint(path, nil, 176 - offsetX, 563 - offsetY)
        CGPathAddLineToPoint(path, nil, 163 - offsetX, 477 - offsetY)
        CGPathAddLineToPoint(path, nil, 130 - offsetX, 399 - offsetY)
        CGPathAddLineToPoint(path, nil, 103 - offsetX, 319 - offsetY)
        CGPathAddLineToPoint(path, nil, 77 - offsetX, 230 - offsetY)
        CGPathAddLineToPoint(path, nil, 66 - offsetX, 129 - offsetY)
        CGPathAddLineToPoint(path, nil, 74 - offsetX, 33 - offsetY)
        CGPathAddLineToPoint(path, nil, 81 - offsetX, 0 - offsetY)
        CGPathAddLineToPoint(path, nil, -1 - offsetX, 2 - offsetY)
        
        CGPathCloseSubpath(path)
        
        sprite.physicsBody = SKPhysicsBody(polygonFromPath: path)
        //-----------------------------------------------------------
        //did not want grass to move so I set it to false.
        sprite.physicsBody?.affectedByGravity = false
        // farther fixing it in place.
        sprite.physicsBody?.dynamic = false
        
    }
    
    func createRightRoadWithPhysics() {
        let right = SKSpriteNode(imageNamed: "grassRight.png")
        right.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        self.addChild(right)
        //=======================================================
        //Got from: http://mortenjust.com/path-generator///much //easier then figuring it out by hand.
        let offsetX = right.size.width * right.anchorPoint.x
        let offsetY = right.size.height * right.anchorPoint.y
        
        let path = CGPathCreateMutable()
        
        CGPathMoveToPoint(path, nil, 477 - offsetX, 799 - offsetY)
        CGPathAddLineToPoint(path, nil, 271 - offsetX, 797 - offsetY)
        CGPathAddLineToPoint(path, nil, 332 - offsetX, 669 - offsetY)
        CGPathAddLineToPoint(path, nil, 366 - offsetX, 555 - offsetY)
        CGPathAddLineToPoint(path, nil, 342 - offsetX, 449 - offsetY)
        CGPathAddLineToPoint(path, nil, 295 - offsetX, 338 - offsetY)
        CGPathAddLineToPoint(path, nil, 255 - offsetX, 139 - offsetY)
        CGPathAddLineToPoint(path, nil, 261 - offsetX, 34 - offsetY)
        CGPathAddLineToPoint(path, nil, 273 - offsetX, 1 - offsetY)
        CGPathAddLineToPoint(path, nil, 478 - offsetX, 3 - offsetY)
        
        CGPathCloseSubpath(path)
        
        right.physicsBody = SKPhysicsBody(polygonFromPath: path)
        //====================================================
        right.physicsBody?.affectedByGravity = false
        right.physicsBody?.dynamic = false
        
    }
    
}


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0.5, y: 0.5, width: 480, height: 800))

skView.showsNodeCount = true
skView.showsFPS = true
skView.showsPhysics = true

let scene = Scene(size: CGSize(width: 480, height: 800))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView

