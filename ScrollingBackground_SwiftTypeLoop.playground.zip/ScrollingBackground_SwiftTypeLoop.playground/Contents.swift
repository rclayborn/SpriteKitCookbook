//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
     var isAlive = true
    
    override init(size: CGSize) {
        super.init(size: size)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        backgroundColor = SKColor.blackColor()
        createBackgrounds()
    }
    
        override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
            isAlive = false  // to stop movement.
        }
        override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
            isAlive = true  //restarts movement.
        }
        
        func createBackgrounds() {
            for i in 0...2 {
                let bg = SKSpriteNode(imageNamed: "blackSky")
                bg.name = "BG"
                bg.zPosition = 0
                bg.anchorPoint = CGPoint(x: 0.5, y: 0.0)
                bg.position = CGPoint(x: CGFloat(i) * bg.size.width, y: 0)
                self.addChild(bg)
            }
        }
        
        func moveBackgrounds() {
            enumerateChildNodesWithName("BG", usingBlock: ({
                (node, error) in
                
                node.position.x -= 4.5
                
                if node.position.x < -(self.frame.width) {
                    node.position.x += self.frame.width * 3// * 3 controls speed
                }
                
            }));
        }
        
        override func update(currentTime: NSTimeInterval) {
            if isAlive {
                moveBackgrounds();
            }
        }
        
    }


//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 1024, height: 786))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 1024, height: 786))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView

