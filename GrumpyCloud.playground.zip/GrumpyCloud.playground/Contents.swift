//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    override init(size: CGSize) {
        super.init(size: size)
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        
        let cloud = SKSpriteNode(imageNamed: "cloud.png")
        cloud.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.8)
        cloud.zPosition = 1
        cloud.xScale = 0.3
        cloud.yScale = 0.3
        self.addChild(cloud)
        
        createCloud()
    }
    
    func createCloud() {
        let sprite = SKSpriteNode(imageNamed: "squirrel.png")
        sprite.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.15)
        sprite.zPosition = 1
        sprite.xScale = 0.1
        sprite.yScale = 0.1
        self.addChild(sprite)
    }
    
    func thunder() {
        let thunder = SKSpriteNode(imageNamed: "Thunder.png")
        thunder.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.8)
        thunder.zPosition = 0
        thunder.xScale = 0.2
        thunder.yScale = 0.2
        self.addChild(thunder)
        
        let moveDown = SKAction.moveToY(0.5, duration: 1)
        let disappear = SKAction.fadeAlphaTo(0.0, duration: 0.0)
        thunder.runAction(SKAction.sequence([moveDown, disappear]))
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        thunder()
    }
}

//playground scene setup-----------------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 480))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 800, height: 480))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
