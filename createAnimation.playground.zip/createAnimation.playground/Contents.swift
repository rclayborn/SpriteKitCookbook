
import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    var player: SKSpriteNode!
    
    override init(size: CGSize) {
        super.init(size: size)
       // physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMoveToView(view: SKView) {
        createPlayer()
        createSky()
        createBackground()
        createGround()
    }
  
        func createPlayer() {
            let playerTexture = SKTexture(imageNamed: "Trumpet-1")
            player = SKSpriteNode(texture: playerTexture)
            player.zPosition = 10
            player.setScale(0.3)
            player.position = CGPoint(x: frame.width / 2, y: frame.height * 0.32)
    
            addChild(player)
    
            let frame2 = SKTexture(imageNamed: "Trumpet-2")
            let frame3 = SKTexture(imageNamed: "Trumpet-3")
            let animation = SKAction.animateWithTextures([playerTexture, frame2, frame3, frame2], timePerFrame: 0.08)
            let runForever = SKAction.repeatActionForever(animation)
    
            player.runAction(runForever)
        }
    
    func createSky() {
        
        let bottomSky = SKSpriteNode(color: UIColor(hue: 0.55, saturation: 0.16, brightness: 0.0, alpha: 1), size: CGSize(width: frame.width, height: frame.height * 0.33))
        bottomSky.position = CGPoint(x: frame.midX, y: bottomSky.frame.height / 2)
        
        addChild(bottomSky)
        
        bottomSky.zPosition = -40
    }
    
    func createBackground() {
        let backgroundTexture = SKTexture(imageNamed: "groundGray")
        
        for i in 0 ... 1 {
            let background = SKSpriteNode(texture: backgroundTexture)
            background.zPosition = -30
            background.anchorPoint = CGPointZero
            background.position = CGPoint(x: (backgroundTexture.size().width * CGFloat(i)) - CGFloat(1 * i), y: 100)
            addChild(background)
            
            let moveLeft = SKAction.moveByX(-backgroundTexture.size().width, y: 0, duration: 20)
            let moveReset = SKAction.moveByX(backgroundTexture.size().width, y: 0, duration: 0)
            let moveLoop = SKAction.sequence([moveLeft, moveReset])
            let moveForever = SKAction.repeatActionForever(moveLoop)
            
            background.runAction(moveForever)
        }
    }
    
    func createGround() {
        let groundTexture = SKTexture(imageNamed: "groundRed")
        
        for i in 0 ... 1 {
            let ground = SKSpriteNode(texture: groundTexture)
            ground.zPosition = -10
            ground.position = CGPoint(x: (groundTexture.size().width / 2.0 + (groundTexture.size().width * CGFloat(i))), y: groundTexture.size().height / 1.45)
            
            addChild(ground)
            
            let moveLeft = SKAction.moveByX(-groundTexture.size().width, y: 0, duration: 5)
            let moveReset = SKAction.moveByX(groundTexture.size().width, y: 0, duration: 0)
            let moveLoop = SKAction.sequence([moveLeft, moveReset])
            let moveForever = SKAction.repeatActionForever(moveLoop)
            
            ground.runAction(moveForever)
        }
    }
    
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 600, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
