//: Playground - noun: a place where people can play

import UIKit
import SpriteKit

var ball = SKSpriteNode(imageNamed: "ball.png")
var otherSprite = SKSpriteNode(imageNamed: "otherSprite")


ball.anchorPoint = CGPointMake(0.5,0.5);
//the anchor point in exactly in the middle and if you change position of the ball like:

ball.position == CGPointMake(50,50);
//the ball center will be exactly in that point (50, 50).

//but if the anchor point will be:

ball.anchorPoint = CGPointMake(1, 1);
//and you change the position to :

ball.position == CGPointMake(50,50);
//the ball centre will be in
//X = 50 - (ball width / 2)
//Y = 50 - (ball height / 2)
//If you want to set up ball position base on other sprite node you can do something like that:

//Attach left centre side of ball to other sprite:
ball.anchorPoint = CGPointMake(0, 0.5);
ball.position.x == otherSprit.position.x + otherSprit.size.with;
ball.position.y == otherSprit.position.y;

//Attach right centre side of ball to other sprite:
ball.anchorPoint = CGPointMake(1, 0.5);
ball.position.x == otherSprit.position.x;
ball.position.y == otherSprit.position.y;
