//: Playground Blink Action 

import UIKit
import SpriteKit
import XCPlayground

class Scene: SKScene {
    
    let player = SKSpriteNode(imageNamed: "player.png")
    let blinkTimes = 10.0
    let duration = 3.0
    
    override func didMoveToView(view: SKView) {
        
        player.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.5)
        player.zPosition = 1
        player.size.width = self.size.width/4
        player.size.height = self.size.height/4
        self.addChild(player)
        
        let blinkAction = SKAction.customActionWithDuration(duration) {
            node, elapsedTime in
            let slice = self.duration / self.blinkTimes
            let remainder = Double(elapsedTime) % slice
            node.hidden = remainder > slice / 2
        }
        player.runAction(blinkAction)
    }
}

//playground scene setup.
let scene = Scene()
scene.scaleMode = .AspectFill

let view = SKView(frame: CGRect(x: 0, y: 0, width: 1920, height: 1080)) // adjust size.
view.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = view
