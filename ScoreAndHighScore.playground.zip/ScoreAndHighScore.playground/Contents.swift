//Randall Clayborn

import UIKit
import SpriteKit
import XCPlayground //at top

class Scene: SKScene {
    //var and let
    var gameOver = Bool()
    var button = SKSpriteNode(imageNamed: "nextButton")
    var button2 = SKSpriteNode(imageNamed: "playButtonBlack")
    var scoreLabel = SKLabelNode(fontNamed: "CopperPlate")
    var highScoreLabel = SKLabelNode()
    var score = Int()
    var highScore = Int()

    override init(size: CGSize) {
        super.init(size: size)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
        gameOver = false
        backgroundColor = SKColor.whiteColor()
        
        button.position = CGPointMake(self.size.width * 0.8, self.size.height * 0.7)
        button.yScale = 0.3
        button.xScale = 0.3
        button.zPosition = -1
        self.addChild(button)
        
        button2.position = CGPointMake(self.size.width * 0.2, self.size.height * 0.7)
        button2.zPosition = -1
        button2.yScale = 0.4
        button2.xScale = 0.4
        self.addChild(button2)
        
        highScoreLabel = SKLabelNode(fontNamed: "CopperPlate")
        highScoreLabel.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.4)
        highScoreLabel.fontSize = 50
        highScoreLabel.fontColor = SKColor.brownColor()
        self.addChild(highScoreLabel)
        
        scoreLabel = SKLabelNode(fontNamed: "CopperPlate")
        scoreLabel.position = CGPointMake(self.size.width * 0.5, self.size.height * 0.5)
        scoreLabel.text = "0"
        scoreLabel.fontSize = 40
        scoreLabel.fontColor = SKColor.blackColor()
        self.addChild(scoreLabel)
        
        GameState.sharedInstance.score = 0
        GameState.sharedInstance.highScore = 0
        score = 0
        highScoreLabel.text = String(format: "%d", GameState.sharedInstance.highScore)
        
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        for touch in touches {
            let touchLocation = touch.locationInNode(self)
            if (CGRectContainsPoint(button.frame, touchLocation)) {
                //call another method or do something here when ClosetDoor is touched.
                reset()
            }
            if (CGRectContainsPoint(button2.frame, touchLocation)) {
                //call another method or do something here when ClosetDoor is touched.
                score += 10
            }
        }
    }
    
    func reset() {
        score = 0
    }
    
    
    func endGame() {
        gameOver = true
        
        // Save stars and high score
        GameState.sharedInstance.saveState()
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        if (self.score >= 0) {
            if score >= highScore {
                highScore = score
                highScoreLabel.text = String(format: "%d", GameState.sharedInstance.highScore)
            }
            scoreLabel.text = "Score: \(score)"
            highScoreLabel.text = "HighScore: \(highScore)"
            
        }
    }

}

//----------------------------
//divide into this second class. 
//Show Singleton

class GameState {
    
    var score: Int
    var highScore: Int
    // var stars: Int //This is for another item you may want to store.
    
    class var sharedInstance :GameState {
        struct Singleton {
            static let instance = GameState()
        }
        
        return Singleton.instance
    }
    
    init() {
        // Init
        score = 0
        highScore = 0
        //stars = 0
        
        // Load game state
        let defaults = NSUserDefaults.standardUserDefaults()
        
        highScore = defaults.integerForKey("highScore")
        // stars = defaults.integerForKey("stars")
    }
    
    func saveState() {
        // Update highScore if the current score is greater
        highScore = max(score, highScore)
        
        // Store in user defaults
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setInteger(highScore, forKey: "highScore")
        //defaults.setInteger(stars, forKey: "stars")
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
}

//playground scene setup.
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 800, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 800, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView
