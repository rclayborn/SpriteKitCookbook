//: Playground - noun: a place where people can play

import UIKit
import SpriteKit
import XCPlayground //at top
//------------------------------


class Scene: SKScene {
    //var and let
    
    override init(size: CGSize) {
        super.init(size: size)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMoveToView(view: SKView) {
            /* Setup your scene here */
            let logo = SKSpriteNode(imageNamed:"YellowAlien.png")
            
            logo.position = CGPointMake(self.frame.size.width/2, self.frame.size.height/2)
            logo.setScale(0.2)
        
            self.addChild(logo)
            
            let path = CGPathCreateMutable()
            CGPathMoveToPoint(path, nil, 0, 0)
            CGPathAddLineToPoint(path, nil, 50, 100)
            let followLine = SKAction.followPath(path, asOffset: true, orientToPath: false, duration: 3.0)
            
            let reversedLine = followLine.reversedAction()
            
            let square = UIBezierPath(rect: CGRectMake(0, 0, 100, 100))
            let followSquare = SKAction.followPath(square.CGPath, asOffset: true, orientToPath: false, duration: 5.0)
            
            let circle = UIBezierPath(roundedRect: CGRectMake(0, 0, 100, 100), cornerRadius: 100)
            let followCircle = SKAction.followPath(circle.CGPath, asOffset: true, orientToPath: false, duration: 5.0)
        
            logo.runAction(SKAction.sequence([followLine,reversedLine,followSquare,followCircle]))
        }
    }


//playground scene setup------------
let skView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 400))

skView.showsNodeCount = true
skView.showsFPS = true

let scene = Scene(size: CGSize(width: 600, height: 400))
skView.presentScene(scene)
XCPlaygroundPage.currentPage.liveView = skView